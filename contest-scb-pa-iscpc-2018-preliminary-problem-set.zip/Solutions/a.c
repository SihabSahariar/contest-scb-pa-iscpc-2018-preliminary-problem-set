#include<stdio.h>

int main()
{
int a;
for(a=10;a>=1;a=a-1){
    printf("%d\n",a);
}

return 0;
}
