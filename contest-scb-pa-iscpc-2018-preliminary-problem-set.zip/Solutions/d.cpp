#include<bits/stdc++.h>

main()
{
    char str[110];
    scanf("%s",str);
    int len = strlen(str);

    int count = 0;

    for(int i=0; i<len; i++)
        if(str[i] == 'm') count++;

    for(int i=1; i<len; i++){

        scanf("%s",str);
        int len2 = strlen(str);

        for(int j=0; j<len2; j++)
            if(str[j] == 'm') count++;
    }

    printf("%d",count);
}
