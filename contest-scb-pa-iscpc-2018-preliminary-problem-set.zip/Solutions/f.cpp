#include<bits/stdc++.h>

main()
{
    int tem, sum = 0;;

    while(scanf("%d",&tem) == 1){

        sum += tem;
    }

    printf("%d",sum);
}
