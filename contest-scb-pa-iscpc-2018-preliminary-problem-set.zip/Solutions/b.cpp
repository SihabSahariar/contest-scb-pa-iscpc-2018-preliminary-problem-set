#include<bits/stdc++.h>

main()
{
    double s, area, a, b, c;
    long long  t;
    scanf("%lld",&t);

    char str[] = "Oh, No!";

    for(long long p=1; p<=t; p++)
    {

        scanf("%lf%lf%lf", &a, &b, &c);

        if( a+b < c )
        {
            puts(str);
        }
        else if( b+c < a )
        {
            puts(str);
        }
        else if( a+c < b )
        {
            puts(str);
        }
        else
        {
            s = (a+b+c) / 2;
            double valu = s * (s - a) * (s - b) * (s - c);
            area = sqrt(valu);

            printf("%.2lf\n", area);
        }
    }
}
