#include<bits/stdc++.h>

main()
{
    int t;
    scanf("%d",&t);

    for(int i=1; i<=t; i++){

        char str[100];
        scanf("%s",&str);

        int len = strlen(str);

        for(int j=0; j<len; j++){

            if(str[j]<'0' || str[j]>'9'){

                int minidx = j;
                char tem;

                for(int k=j+1; k<len; k++){

                    if(str[k]<'0' || str[k]>'9')
                        if(str[k] < str[minidx]) minidx = k;
                }

                tem = str[j];
                str[j] = str[minidx];
                str[minidx] = tem;

                //printf("%s\n",str);
            }

            else{

                int minidx = j;
                char tem;

                for(int k=j+1; k<len; k++){

                    if(str[k]>='0' && str[k]<='9')
                        if(str[k] < str[minidx]) minidx = k;
                }

                tem = str[j];
                str[j] = str[minidx];
                str[minidx] = tem;

                //printf("%s\n",str);
            }
        }

        printf("%s\n",str);
    }
}
